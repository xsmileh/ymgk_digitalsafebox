# py_sign_verify
Python Sign and Verify Script

Python script to Sign a binary as well as verify the signature.

Usage:
            digi-sig -s  <priv-key> <data> <signature-file>
            digi-sig -v  <PUB-key> <data> <signature-file> 
  
